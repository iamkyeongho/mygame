package mygame;

public class CTerminal 
{
	public static void Print(String message)
	{
		System.out.print(message);		
	}
	public static void Println(String message)
	{
		System.out.println(message);		
	}
}
