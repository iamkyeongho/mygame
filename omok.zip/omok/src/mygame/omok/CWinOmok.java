package mygame.omok;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import mygame.CWindow;

public class CWinOmok extends COmok implements ActionListener
{
	private final String TITLE = "오목";
	
	private CWindow window;
	private JPanel panelGrid;
	private JTextArea message;
	
	public static void main(String[] args) 
	{
		new CWinOmok();
	}

	public CWinOmok()
	{
		this.initWindow();
	}
	
	private void initWindow()
	{
		window = new CWindow();
		window.setTitle(TITLE);
		window.setLayout(new BorderLayout());
		
		this.panelGrid = new JPanel();
		this.panelGrid.setLayout(new GridLayout(BoardSize-1,BoardSize-1,3,3));	
		window.add("Center", this.panelGrid);
		this.DrawBoard();
		
		message = new JTextArea("   오목 게임을 시작합니다. O가 놓을 위치를 클릭하세요.");		
		window.add("South", message);
		
		window.setResizable(true);
		window.setVisible(true);		
	}

	@Override
	public void Play() {}

	@Override
	public void DrawBoard() 
	{
		for (int i = 0; i < BoardSize-1; i++)
		{
			for (int j = 0; j < BoardSize-1; j++)
			{
				JButton stone = new JButton(" ");
				stone.setName(String.format("%d-%d", i+1, j+1));
				stone.addActionListener(this);
				this.panelGrid.add(stone);
			}
		}		
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		String eventClass = e.getSource().getClass().getSimpleName();
		if (eventClass.equals("JButton"))
		{
			JButton btn = (JButton)e.getSource(); 
			String[] position = btn.getName().split("-");			
			try 
			{				
				char stone = this.PlaceStone(Integer.parseInt(position[0]), Integer.parseInt(position[1]));
				btn.setText(String.format("%c", stone));
				
				if (this.findFiveStones(x, y))
				{				
					CWindow.ShowMessageBox(String.format("%s의 승리입니다.", board[x][y]));				
				}
			} 
			catch (Exception ex) 
			{
				CWindow.ShowMessageBox(ex.getMessage());	
			}
		}
	}

	@Override
	public void PlaceStone() throws Exception { }

	@Override
	public char PlaceStone(int row, int col) throws Exception 
	{		
		x = row;
		y = col;
		
		if(turn == 1)			
		{
			board[x][y] = 'O';			
			turn = 0;
			count ++;
		}
		else if(turn == 0)
		{
			board[x][y] = '⬤';
			turn = 1;
			count ++;
		}
		CWindow.PrintMessage(message, String.format("%c : %d-%d",  board[x][y], row, col));
		return board[x][y];
	}
}
