package mygame.omok;

import java.util.Scanner;

import mygame.CTerminal;

public class CTxtOmok extends COmok 
{
	public static void main(String[] args) 
	{
		CTxtOmok game = new CTxtOmok();
		game.Play();
	}

	public CTxtOmok()
	{ }
	
	@Override
	public void Play()
	{
		do 
		{
			try
			{
				this.DrawBoard();
				this.PlaceStone();
				if (this.findFiveStones(x, y))
				{
					this.DrawBoard();
					CTerminal.Println(String.format("%s의 승리입니다.", board[x][y]));
					break;
				}
			}
			catch (Exception ex)
			{
				CTerminal.Println(String.format("에러 : %s", ex.getMessage()));
			}			
		} while (count < MaxCount);
		CTerminal.Println("게임을 종료합니다.");
	}
	
	@Override
	public void DrawBoard()
	{
		CTerminal.Println("  1   2   3   4   5   6   7   8   9  10   11  12  13  14  15");
		for (int i = 1; i < BoardSize; i++)
		{
			CTerminal.Println("-------------------------------------------------------------");
			CTerminal.Println("| "+board[i][1]+" | "+board[i][2]+" | "+board[i][3]+" | " + board[i][4]+ " | "
					+board[i][5]+" | "+board[i][6]+" | " + board[i][7]+ " | " +board[i][8]+" | "+board[i][9]+" | " + board[i][10]
					+" | "+board[i][11]+" | "+board[i][12]+" | " + board[i][13]+" | "+board[i][14]+" | "+board[i][15]+" | "+ i);			
		}
		CTerminal.Println("-------------------------------------------------------------");		
	}
	
	@Override
	public char PlaceStone(int row, int col) throws Exception { return 0;}	
	
	@Override
	public void PlaceStone() throws Exception
	{
		if (turn == 1)
		{
			CTerminal.Print("O가 놓을 위치를 정하시오[1~15][1~15]: ");			
		}
		else if(turn == 0)
		{
			CTerminal.Print("⬤가 놓을 위치를 정하시오[1~15][1~15]: ");
		}
		
		Scanner input = new Scanner(System.in);
		x = input.nextInt();
		y = input.nextInt();

		if (!this.checkPosition(x, y))
			throw new Exception(String.format("위치는 1부터 %d사이의 정수입니다.", BoardSize-1));		
		if (board[x][y] != ' ')
			throw new Exception("이미 돌이 있습니다. 다른 위치에 놓아주세요!");
		
		if(turn == 1)			
		{
			board[x][y] = 'O';
			turn = 0;
			count ++;
		}
		else if(turn == 0)
		{
			board[x][y] = '⬤';
			turn = 1;
			count ++;
		}			
	}	
}
