package mygame.omok;

public abstract class COmok 
{
	protected final int BoardSize = 16;
	protected final int MaxCount = 225;
	protected final int OMOK = 5;
	
	protected int turn = 1;
	protected int x = 0;
	protected int y = 0;
	protected int count = 0;
	
	protected char[][] board = new char[BoardSize][BoardSize];
		
	public COmok()
	{ 
		this.initVariables();
	}
	
	public abstract void Play();
	public abstract void DrawBoard();
	public abstract void PlaceStone() throws Exception;
	public abstract char PlaceStone(int row, int col) throws Exception;
	
	protected void initBoard()
	{
		for(int i = 1; i < BoardSize; i++)
		{
			for(int j = 1; j < BoardSize; j++)
			{
				board[i][j] = ' ';
			}
		}
	}
	
	protected void initVariables()
	{
		turn = 1;
		x = 0;
		y = 0;
		count = 0;
		this.initBoard();
	}
		
	protected boolean findCols(int row, int col)
	{
		int find = 1;
		char myturn = board[row][col];
		char stone = ' ';
		
		for (int i = 1; i < 5; i++)
		{
			if (!this.checkPosition(row-i, col)) 
				break;
			
			stone = board[row-i][col];
			if((row-i >= 1) && (stone == myturn))
			{
				find++;
			}
			else
			{
				break;
			}
		}
		for (int i = 1; i < 5; i++)
		{
			if (!this.checkPosition(row+i, col+i)) 
				break;
			
			stone = board[row+i][col];
			if((row+i >= BoardSize) && (stone == myturn))
			{
				find++;
			}
			else
			{
				break;
			}
		}
		
		if (find == OMOK)
		{
			return true;
		}
		else
		{
			return false;
		}		
	}
	
	protected boolean findRows(int row, int col)
	{
		int find = 1;
		char myturn = board[row][col];
		char stone = ' ';
		
		for(int i = 1; i < 5; i++) 
		{	
			if (!this.checkPosition(row, col-i)) 
				break;
			
			stone = board[row][col-i];
			if((col-i >= 1) && (stone == myturn))
			{
				find++;
			}
			else
			{
				break;
			}
		}
		for(int i = 1; i < 5; i++) 
		{		
			if (!this.checkPosition(row, col+i)) 
				break;
			
			stone = board[row][col+i];
			if((col+i < BoardSize) && (stone == myturn))
			{
				find++;
			}
			else
			{
				break;
			}
		}

		if (find == OMOK)
		{
			return true;
		}
		else
		{
			return false;
		}		
	}
	
	protected boolean checkPosition(int row, int col)
	{
		if (row > 0 && row < BoardSize)
		{
			if (col > 0 && col < BoardSize)
			{
				return true;
			}
		}
		return false;
	}
	
	protected boolean findDiagonals(int row, int col)
	{
		int find = 1;
		char myturn = board[row][col];
		char stone = ' ';
		
		// 아래쪽 + 오른쪽
		for(int i = 1; i < 5; i++)
		{
			if (!this.checkPosition(row+i, col+i)) 
				break;
			
			stone = board[row+i][col+i];
			if(stone == myturn)
			{
				find++;
			}
			else
			{
				break;			
			}
		}
		// 윗쪽 + 왼쪽
		for(int i = 1; i < 5; i++)
		{		
			if (!this.checkPosition(row-i, col-i)) 
				break;
			
			stone = board[row-i][col-i];
			if(stone == myturn)
			{
				find++;
			}
			else
			{
				break;
			}
		}
		if (find == OMOK)
		{
			return true;
		}
		
		// 방향 바꿔서 다시 초기화.
		find = 1;
		// 아래쪽 + 왼쪽
		for(int i = 1; i < 5; i++)
		{
			if (!this.checkPosition(row-i, col-i)) 
				break;
			
			stone = board[row+i][col-i];
			if(stone == myturn)
			{
				find++;
			}
			else
			{
				break;
			}
		}
		// 윗쪽 + 오른쪽
		for(int i = 1; i < 5; i++)
		{		
			if (!this.checkPosition(row-i, col+i)) 
				break;
			
			stone = board[row-i][col+i];
			if(stone == myturn)
			{
				find++;
			}
			else
			{
				break;
			}
		}
		
		if (find == OMOK)
		{
			return true;
		}
		else
		{
			return false;
		}		
	}
	
	protected boolean findFiveStones(int row, int col)
	{
		if (this.findCols(row, col))
			return true;
		if (this.findRows(row, col))
			return true;
		if (this.findDiagonals(row, col))
			return true;
		return false;
	}
}
